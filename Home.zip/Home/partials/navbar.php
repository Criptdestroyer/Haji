<body>
    
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container">
      <a class="navbar-brand" href="index.php">Haji</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="oi oi-menu"></span> Menu
      </button>

      <div class="collapse navbar-collapse" id="ftco-nav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
          <li class="nav-item"><a href="regulasi.php" class="nav-link">Regulasi</a></li>
          <li class="nav-item"><a href="publikasi.php" class="nav-link">Publikasi</a></li>
          <li class="nav-item"><a href="multimedia.php" class="nav-link">Multimedia</a></li>
          <li class="nav-item"><a href="contact.php" class="nav-link">Tentang</a></li>
        </ul>
      </div>
    </div>
  </nav>
