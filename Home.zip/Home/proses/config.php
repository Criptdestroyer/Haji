<?php
$server = "fdb26.awardspace.net";
$user = "3085597_haji";
$password = "adminhaji8";
$nama_database = "3085597_haji";

$db = mysqli_connect($server, $user, $password, $nama_database);

if( !$db ){
    die("Gagal terhubung dengan database: " . mysqli_connect_error());
}